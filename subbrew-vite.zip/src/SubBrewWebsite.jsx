export default function SubBrewWebsite() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial, sans-serif' }}>
      <h1 style={{ fontSize: '3rem' }}>SubBrew</h1>
      <p>Your Daily Brew, On the Move – Serving Artisan Coffee & Toasties at Bank Station</p>
    </div>
  );
}
