import React from "react";
import ReactDOM from "react-dom/client";
import SubBrewWebsite from "./SubBrewWebsite";

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<SubBrewWebsite />);
